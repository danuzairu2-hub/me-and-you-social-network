-- Me & You production-minded starter schema for Supabase/Postgres.
create extension if not exists pgcrypto;

do $$ begin create type public.user_role as enum ('user','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.friendship_status as enum ('pending','accepted','blocked'); exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'New member' check (char_length(display_name) between 2 and 80),
  username text unique check (username is null or username ~ '^[a-z0-9_]{3,30}$'),
  bio text not null default '' check (char_length(bio) <= 500),
  avatar_url text,
  cover_url text,
  role public.user_role not null default 'user',
  created_at timestamptz not null default now()
);
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now()
);
create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);
create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status public.friendship_status not null default 'pending',
  created_at timestamptz not null default now(),
  unique(requester_id,addressee_id),
  check(requester_id <> addressee_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 5000),
  created_at timestamptz not null default now(),
  check(sender_id <> receiver_id)
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  type text not null,
  title text not null,
  body text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reason text not null check(char_length(reason) between 3 and 500),
  status text not null default 'open' check(status in ('open','reviewed','resolved')),
  created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_author_idx on public.posts(author_id, created_at desc);
create index if not exists messages_pair_idx on public.messages(sender_id, receiver_id, created_at desc);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
create index if not exists friendships_participants_idx on public.friendships(requester_id, addressee_id, status);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name,username)
  values(new.id,coalesce(nullif(new.raw_user_meta_data->>'display_name',''),'New member'),nullif(new.raw_user_meta_data->>'username',''))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

create or replace function public.protect_profile_role() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if old.role <> new.role and not public.is_admin() then new.role := old.role; end if;
  return new;
end; $$;
drop trigger if exists protect_profile_role_trigger on public.profiles;
create trigger protect_profile_role_trigger before update on public.profiles for each row execute procedure public.protect_profile_role();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;

-- Drop/recreate policies so this script can be safely rerun during development.
do $$ declare p record; begin
  for p in select policyname,tablename from pg_policies where schemaname='public' and tablename in ('profiles','posts','post_likes','friendships','messages','notifications','reports') loop
    execute format('drop policy if exists %I on public.%I',p.policyname,p.tablename);
  end loop;
end $$;

create policy profiles_select on public.profiles for select to authenticated using (true);
create policy profiles_insert on public.profiles for insert to authenticated with check (id=auth.uid());
create policy profiles_update on public.profiles for update to authenticated using (id=auth.uid() or public.is_admin()) with check (id=auth.uid() or public.is_admin());

create policy posts_select on public.posts for select to authenticated using (true);
create policy posts_insert on public.posts for insert to authenticated with check (author_id=auth.uid());
create policy posts_update on public.posts for update to authenticated using (author_id=auth.uid()) with check (author_id=auth.uid());
create policy posts_delete on public.posts for delete to authenticated using (author_id=auth.uid() or public.is_admin());

create policy likes_select on public.post_likes for select to authenticated using (true);
create policy likes_insert on public.post_likes for insert to authenticated with check (user_id=auth.uid());
create policy likes_delete on public.post_likes for delete to authenticated using (user_id=auth.uid());

create policy friendships_select on public.friendships for select to authenticated using (requester_id=auth.uid() or addressee_id=auth.uid());
create policy friendships_insert on public.friendships for insert to authenticated with check (requester_id=auth.uid() and requester_id<>addressee_id);
create policy friendships_update on public.friendships for update to authenticated using (requester_id=auth.uid() or addressee_id=auth.uid()) with check (requester_id=auth.uid() or addressee_id=auth.uid());
create policy friendships_delete on public.friendships for delete to authenticated using (requester_id=auth.uid() or addressee_id=auth.uid());

create policy messages_select on public.messages for select to authenticated using (sender_id=auth.uid() or receiver_id=auth.uid());
create policy messages_insert on public.messages for insert to authenticated with check (sender_id=auth.uid());
create policy messages_delete on public.messages for delete to authenticated using (sender_id=auth.uid());

create policy notifications_select on public.notifications for select to authenticated using (user_id=auth.uid());
create policy notifications_update on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());

create policy reports_insert on public.reports for insert to authenticated with check (reporter_id=auth.uid());
create policy reports_select on public.reports for select to authenticated using (reporter_id=auth.uid() or public.is_admin());
create policy reports_update on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());

create or replace function public.notify_friend_request() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.notifications(user_id,actor_id,type,title,body) values(new.addressee_id,new.requester_id,'friend_request','New friend request','You received a new friend request.'); return new; end; $$;
drop trigger if exists friendship_notification_trigger on public.friendships;
create trigger friendship_notification_trigger after insert on public.friendships for each row when (new.status='pending') execute procedure public.notify_friend_request();

create or replace function public.notify_like() returns trigger language plpgsql security definer set search_path=public as $$
declare owner_id uuid;
begin select author_id into owner_id from public.posts where id=new.post_id; if owner_id is not null and owner_id<>new.user_id then insert into public.notifications(user_id,actor_id,type,title,body) values(owner_id,new.user_id,'like','New like','Someone liked your post.'); end if; return new; end; $$;
drop trigger if exists like_notification_trigger on public.post_likes;
create trigger like_notification_trigger after insert on public.post_likes for each row execute procedure public.notify_like();

-- Realtime chat. If already added, PostgreSQL may report a duplicate publication membership;
-- run this line once manually if your project reports that warning.
alter publication supabase_realtime add table public.messages;

-- Social feature tables
alter table public.profiles add column if not exists cover_url text;
create table if not exists public.stories (id uuid primary key default gen_random_uuid(), author_id uuid not null references public.profiles(id) on delete cascade, media_url text, caption text default '', created_at timestamptz not null default now(), expires_at timestamptz not null default now()+interval '24 hours');
create table if not exists public.reels (id uuid primary key default gen_random_uuid(), author_id uuid not null references public.profiles(id) on delete cascade, video_url text not null, caption text default '', created_at timestamptz not null default now());
create table if not exists public.comments (id uuid primary key default gen_random_uuid(), post_id uuid not null references public.posts(id) on delete cascade, author_id uuid not null references public.profiles(id) on delete cascade, body text not null check(char_length(body) between 1 and 2000), created_at timestamptz not null default now());
create table if not exists public.groups (id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade, name text not null check(char_length(name) between 2 and 100), description text default '', cover_url text, is_private boolean not null default false, created_at timestamptz not null default now());
create table if not exists public.group_members (group_id uuid references public.groups(id) on delete cascade, user_id uuid references public.profiles(id) on delete cascade, role text not null default 'member', created_at timestamptz not null default now(), primary key(group_id,user_id));
create table if not exists public.pages (id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade, name text not null, description text default '', avatar_url text, cover_url text, created_at timestamptz not null default now());
create table if not exists public.page_followers (page_id uuid references public.pages(id) on delete cascade, user_id uuid references public.profiles(id) on delete cascade, created_at timestamptz not null default now(), primary key(page_id,user_id));
create table if not exists public.marketplace_items (id uuid primary key default gen_random_uuid(), seller_id uuid not null references public.profiles(id) on delete cascade, title text not null, description text default '', price numeric(12,2) not null check(price>=0), location text default '', image_url text, status text not null default 'active', created_at timestamptz not null default now());
create table if not exists public.presence (user_id uuid primary key references public.profiles(id) on delete cascade, is_online boolean not null default false, last_seen timestamptz not null default now());
create table if not exists public.typing_status (user_id uuid not null references public.profiles(id) on delete cascade, conversation_user_id uuid not null references public.profiles(id) on delete cascade, is_typing boolean not null default false, updated_at timestamptz not null default now(), primary key(user_id,conversation_user_id));
create index if not exists stories_expiry_idx on public.stories(expires_at); create index if not exists comments_post_idx on public.comments(post_id,created_at); create index if not exists marketplace_status_idx on public.marketplace_items(status,created_at desc);

alter table public.stories enable row level security; alter table public.reels enable row level security; alter table public.comments enable row level security; alter table public.groups enable row level security; alter table public.group_members enable row level security; alter table public.pages enable row level security; alter table public.page_followers enable row level security; alter table public.marketplace_items enable row level security; alter table public.presence enable row level security; alter table public.typing_status enable row level security;
create policy stories_select on public.stories for select to authenticated using (expires_at>now() or author_id=auth.uid()); create policy stories_insert on public.stories for insert to authenticated with check(author_id=auth.uid());
create policy reels_select on public.reels for select to authenticated using (true); create policy reels_insert on public.reels for insert to authenticated with check(author_id=auth.uid()); create policy reels_update on public.reels for update to authenticated using(author_id=auth.uid()); create policy reels_delete on public.reels for delete to authenticated using(author_id=auth.uid() or public.is_admin());
create policy comments_select on public.comments for select to authenticated using(true); create policy comments_insert on public.comments for insert to authenticated with check(author_id=auth.uid()); create policy comments_update on public.comments for update to authenticated using(author_id=auth.uid()); create policy comments_delete on public.comments for delete to authenticated using(author_id=auth.uid() or public.is_admin());
create policy groups_select on public.groups for select to authenticated using(true); create policy groups_insert on public.groups for insert to authenticated with check(owner_id=auth.uid()); create policy groups_update on public.groups for update to authenticated using(owner_id=auth.uid() or public.is_admin());
create policy group_members_select on public.group_members for select to authenticated using(true); create policy group_members_insert on public.group_members for insert to authenticated with check(user_id=auth.uid()); create policy group_members_delete on public.group_members for delete to authenticated using(user_id=auth.uid() or public.is_admin());
create policy pages_select on public.pages for select to authenticated using(true); create policy pages_insert on public.pages for insert to authenticated with check(owner_id=auth.uid()); create policy pages_update on public.pages for update to authenticated using(owner_id=auth.uid() or public.is_admin());
create policy page_followers_select on public.page_followers for select to authenticated using(true); create policy page_followers_insert on public.page_followers for insert to authenticated with check(user_id=auth.uid()); create policy page_followers_delete on public.page_followers for delete to authenticated using(user_id=auth.uid());
create policy marketplace_select on public.marketplace_items for select to authenticated using(true); create policy marketplace_insert on public.marketplace_items for insert to authenticated with check(seller_id=auth.uid()); create policy marketplace_update on public.marketplace_items for update to authenticated using(seller_id=auth.uid() or public.is_admin()); create policy marketplace_delete on public.marketplace_items for delete to authenticated using(seller_id=auth.uid() or public.is_admin());
create policy presence_select on public.presence for select to authenticated using(true); create policy presence_upsert on public.presence for insert to authenticated with check(user_id=auth.uid()); create policy presence_update on public.presence for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy typing_select on public.typing_status for select to authenticated using(user_id=auth.uid() or conversation_user_id=auth.uid()); create policy typing_upsert on public.typing_status for insert to authenticated with check(user_id=auth.uid()); create policy typing_update on public.typing_status for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

-- Media bucket for profile/cover/story/reel uploads. Create it in Storage if your project disallows SQL storage changes.
drop policy if exists media_public_read on storage.objects; drop policy if exists media_user_upload on storage.objects; drop policy if exists media_user_update on storage.objects; drop policy if exists media_user_delete on storage.objects;
insert into storage.buckets (id,name,public) values ('media','media',true) on conflict (id) do nothing;
create policy media_public_read on storage.objects for select to public using(bucket_id='media');
create policy media_user_upload on storage.objects for insert to authenticated with check(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy media_user_update on storage.objects for update to authenticated using(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text) with check(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy media_user_delete on storage.objects for delete to authenticated using(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
