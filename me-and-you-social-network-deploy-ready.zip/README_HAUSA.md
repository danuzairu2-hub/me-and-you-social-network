# Me and You — Takaitaccen bayani da Hausa

Wannan project ɗin social network ne na farko (MVP) mai suna **Me and You**.

### Abubuwan da ke ciki
- Homepage
- Signup/Login
- Profile da gyarawa
- Feed da posts
- Like
- Friends da friend requests
- Chat na real-time
- Notifications
- Admin panel
- PostgreSQL database
- Row Level Security
- Shirye don deployment a Vercel

### Yadda zaka fara
1. Ka bude Supabase project.
2. Ka gudanar da `supabase/schema.sql` a SQL Editor.
3. Ka kwafi `.env.example` zuwa `.env.local` ka saka Supabase URL da publishable key.
4. Ka yi `npm install` sannan `npm run dev`.
5. Ka bude `http://localhost:3000`.

Kar ka saka service-role/secret key a frontend. RLS ne yake kare bayanan database.
