'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'

export function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [name,setName]=useState(''); const [username,setUsername]=useState(''); const [busy,setBusy]=useState(false); const [error,setError]=useState(''); const [ok,setOk]=useState('')
  async function submit(e:React.FormEvent){
    e.preventDefault(); setBusy(true); setError(''); setOk(''); const s=supabase()
    if(mode==='signup'){
      if(name.trim().length<2){setError('Please enter your full name.');setBusy(false);return}
      const clean=username.trim().toLowerCase().replace(/[^a-z0-9_]/g,'')
      if(clean.length<3){setError('Username must contain at least 3 letters, numbers or underscores.');setBusy(false);return}
      const {data,error}=await s.auth.signUp({email:email.trim(),password,options:{data:{display_name:name.trim(),username:clean}}})
      if(error){setError(error.message)} else if(data.user){
        if(data.session) window.location.href='/feed'; else setOk('Account created. Check your email to confirm your account, then log in.')
      }
    } else {
      const {error}=await s.auth.signInWithPassword({email:email.trim(),password})
      if(error)setError(error.message);else window.location.href='/feed'
    }
    setBusy(false)
  }
  return <form className="stack" onSubmit={submit}>
    {mode==='signup'&&<><input className="input" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/><input className="input" placeholder="Username (e.g. funny_man)" value={username} onChange={e=>setUsername(e.target.value)} required/></>}
    <input className="input" type="email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="email"/>
    <input className="input" type="password" placeholder="Password (8+ characters)" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required autoComplete={mode==='login'?'current-password':'new-password'}/>
    {error&&<div className="error">{error}</div>}{ok&&<div className="success">{ok}</div>}
    <button className="btn primary big" disabled={busy}>{busy?'Please wait…':mode==='signup'?'Create account':'Log in'}</button>
  </form>
}
