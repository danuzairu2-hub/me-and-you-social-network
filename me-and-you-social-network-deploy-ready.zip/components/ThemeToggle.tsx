'use client'
import {Moon,Sun} from 'lucide-react'; import {useEffect,useState} from 'react'
export function ThemeToggle(){const [dark,setDark]=useState(false);useEffect(()=>{const d=localStorage.getItem('my-theme')==='dark';setDark(d);document.documentElement.classList.toggle('dark',d)},[]);function toggle(){const n=!dark;setDark(n);localStorage.setItem('my-theme',n?'dark':'light');document.documentElement.classList.toggle('dark',n)}return <button className="themebtn" onClick={toggle} aria-label="Toggle dark mode">{dark?<Sun size={18}/>:<Moon size={18}/>}</button>}
