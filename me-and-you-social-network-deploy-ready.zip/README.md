# Me & You — Social Network MVP

A responsive social-network starter built with Next.js, React, TypeScript and Supabase.

## Features
- Landing page
- Email/password signup and login
- Profiles and profile editing
- Social feed and posts
- Likes and automatic like notifications
- Friend requests and friends list
- Real-time private chat
- Notifications
- Admin dashboard and role protection
- PostgreSQL schema with indexes, triggers and Row Level Security

## Local setup
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local` and add your Supabase URL and publishable key.
4. Install dependencies: `npm install`
5. Start development: `npm run dev`
6. Open `http://localhost:3000`.

## Make the first admin
Create your account first. In Supabase SQL Editor, run:

```sql
update public.profiles set role='admin' where username='your_username';
```

## Production deployment
Push this project to GitHub, import it into Vercel, and add the same two environment variables under Project Settings → Environment Variables. Deploy.

## Production hardening checklist
- Enable email verification and a suitable auth redirect URL.
- Configure Supabase Storage for avatars/media.
- Add rate limiting and abuse prevention before public launch.
- Add moderation/report workflows and audit logging.
- Add automated tests and error monitoring.
- Configure backups and database performance monitoring.
- Never expose a Supabase service-role/secret key in browser code.
