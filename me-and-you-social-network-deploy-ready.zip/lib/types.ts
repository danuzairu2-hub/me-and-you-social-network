export type Profile = {
  id: string
  display_name: string
  username: string | null
  bio: string
  avatar_url: string | null
  role: 'user' | 'admin'
  created_at: string
}

export type Post = {
  id: string
  body: string
  created_at: string
  author: Pick<Profile, 'id' | 'display_name' | 'avatar_url'> | null
}
