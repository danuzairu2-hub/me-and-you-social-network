import Link from 'next/link'; import {AuthForm} from '@/components/AuthForm'
export default function Login(){return <main className="auth"><div className="card authbox"><h1>Welcome back</h1><p className="muted">Log in to Me and You.</p><AuthForm mode="login"/><p className="muted">New here? <Link href="/auth/signup">Create an account</Link></p></div></main>}
