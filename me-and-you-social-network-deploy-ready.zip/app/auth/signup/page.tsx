import Link from 'next/link'; import {AuthForm} from '@/components/AuthForm'
export default function Signup(){return <main className="auth"><div className="card authbox"><h1>Join Me and You</h1><p className="muted">Create your profile and start connecting.</p><AuthForm mode="signup"/><p className="muted">Already registered? <Link href="/auth/login">Log in</Link></p></div></main>}
