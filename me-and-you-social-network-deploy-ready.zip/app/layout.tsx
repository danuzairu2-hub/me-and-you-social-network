import './globals.css'
import Link from 'next/link'
import { Navigation } from '@/components/Navigation'

export default function RootLayout({children}:{children:React.ReactNode}){
  return <html lang="en"><body><Navigation/>{children}</body></html>
}
