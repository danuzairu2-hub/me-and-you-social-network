import Link from 'next/link'
import { ArrowRight, MessageCircle, ShieldCheck, Users, Heart, Sparkles } from 'lucide-react'

export default function Home() {
  return <main>
    <section className="hero">
      <div className="container heroGrid">
        <div>
          <div className="eyebrow"><Sparkles size={15}/> Connect. Share. Belong.</div>
          <h1>People first.<br/><span>Me & You.</span></h1>
          <p className="heroText">A simple social network for sharing moments, finding friends, building communities and having real conversations.</p>
          <div className="actions">
            <Link className="btn primary big" href="/auth/signup">Create free account <ArrowRight size={18}/></Link>
            <Link className="btn ghost big" href="/auth/login">I already have an account</Link>
          </div>
          <div className="trust"><ShieldCheck size={17}/> Your account and data are protected by database-level access rules.</div>
        </div>
        <div className="phoneMock">
          <div className="mockTop"><b>Me & You</b><span>•••</span></div>
          <div className="mockProfile"><div className="avatar xl">M</div><div><b>Me & You Community</b><small>12.4k members</small></div></div>
          <div className="mockPost"><div className="row"><div className="avatar">A</div><div><b>Amina</b><small>Just now</small></div></div><p>Good people, good conversations. ❤️</p><div className="mockActions"><span>♡ 248</span><span>💬 36</span><span>↗ Share</span></div></div>
          <div className="mockChat"><MessageCircle size={18}/><span>New message from Daniel</span><b>2m</b></div>
        </div>
      </div>
    </section>
    <section className="container section">
      <div className="sectionHead"><div><div className="eyebrow">Everything you need</div><h2>One place to connect</h2></div><p className="muted">Start small, then grow the platform with communities, stories, video and more.</p></div>
      <div className="three grid">
        <Feature icon={<Users/>} t="Friends & profiles" d="Create your profile, discover people and manage friend requests."/>
        <Feature icon={<Heart/>} t="Social feed" d="Share updates, like posts and join conversations with your community."/>
        <Feature icon={<MessageCircle/>} t="Private chat" d="Talk privately with friends using real-time messaging."/>
      </div>
    </section>
    <section className="container cta"><div><div className="eyebrow">Your community starts here</div><h2>Build your circle on Me & You.</h2></div><Link className="btn primary big" href="/auth/signup">Get started <ArrowRight size={18}/></Link></section>
  </main>
}
function Feature({icon,t,d}:{icon:React.ReactNode,t:string,d:string}){return <div className="card feature"><div className="featureIcon">{icon}</div><h3>{t}</h3><p className="muted">{d}</p></div>}
